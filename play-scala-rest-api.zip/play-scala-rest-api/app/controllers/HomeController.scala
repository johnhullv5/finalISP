package controllers
//implicit val formats = net.liftweb.json.DefaultFormats
import javax.inject.Inject

import play.api.mvc._
import play.api.libs.json._

import net.liftweb.json.JsonAST._
import net.liftweb.json.Extraction._


/**
  * A very small controller that renders a home page.
  */
class HomeController @Inject()(cc: ControllerComponents) extends AbstractController(cc) {
  /*val symbols = Map("symbols" -> List("GOOG","APPL")) 
  def index = Action { implicit request =>
    Ok(Json.toJson(symbols))
  }*/
  
  val data = Map("GOOG"->List(
  Map("symbol" -> "GOOG","date"->"2016-12-03","open"->"10","high"->"15","low"->"8","close"->"8","adj"->"12","vol"->"10000")
  ,Map("symbol" -> "GOOG","date"->"2016-12-04","open"->"10","high"->"15","low"->"8","close"->"8","adj"->"12","vol"->"10000")
  ,Map("symbol" -> "GOOG","date"->"2016-12-05","open"->"1","high"->"10","low"->"8","close"->"8","adj"->"12","vol"->"80000")
  ,Map("symbol" -> "GOOG","date"->"2016-12-06","open"->"1","high"->"10","low"->"8","close"->"10","adj"->"12","vol"->"80000")
  ,Map("symbol" -> "GOOG","date"->"2016-12-07","open"->"1","high"->"10","low"->"8","close"->"11","adj"->"12","vol"->"80000")
    ,Map("symbol" -> "GOOG","date"->"2016-12-08","open"->"1","high"->"10","low"->"8","close"->"13","adj"->"12","vol"->"80000")
	  ,Map("symbol" -> "GOOG","date"->"2016-12-09","open"->"1","high"->"10","low"->"8","close"->"14","adj"->"12","vol"->"80000")
	    ,Map("symbol" -> "GOOG","date"->"2016-12-10","open"->"1","high"->"10","low"->"8","close"->"15","adj"->"12","vol"->"80000")
  
  
  
  
  )
  
  
  
  )
  
  /*val data = Map("symbol" -> "GOOG","date"->"2017-12-04","quote"-> List("10","20","30","40","50","6"))*/
  
  def index = Action { implicit request =>
    Ok(Json.toJson(data))
	}
  
}
